let express = require('express');
let app = express();



var mysql = require("mysql");
var connection = mysql.createConnection({
    host    : 'localhost',
    user    : 'root',
    password: 'root',
    database: 'appartement',
});

connection.connect(function(error){if (error) console.log(error);});

app.use(express.urlencoded({extended: true}));

let session = require('express-session');
app.use(session({
    secret: 'my secret',
    resave: false,
    saveUninitialized: true
    })
);

app.get('/accueil', (req, res) => {
    res.render('accueil.ejs');
});

app.get('/Page_Liste', (req, res) => {
    connection.query("select * from appart;", function(error, result) {
        if (error) console(error);
    res.render('Page_Liste.ejs', {total, test, appart: result});
    });
});

surface=0;
test=0;
app.post('/calcul', (req, res) => {
    req.session.largeur=req.body.largeur;
    req.session.longueur=req.body.longueur;
    req.session.surface=req.session.largeur*req.session.longueur;
    surface=req.session.surface
    res.render('accueil.ejs', {surface});
});

app.post('/save', (req, res) => {
    req.session.pièce=req.body.pièce
    let appart = {"pièce":req.session.pièce, "surface":req.session.surface}
    connection.query("INSERT INTO appart SET ?", appart, function(err, result) {
        if (err) console.log(err);
        test++;
    res.redirect('/Page_Liste');
    });
});


app.listen(8000, function () {
    console.log('runnings on port 8000');
})
